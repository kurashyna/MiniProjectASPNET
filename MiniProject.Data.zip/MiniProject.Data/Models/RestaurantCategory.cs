﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProject.data.Models
{
    public enum RestaurantCategory
    {
        Italian,
        Vegetarian,
        Mexican,
        Japanese,
        Chinese
    }
}